#pragma once

#include "exporting.h"

extern "C" {
    DLL_API void say_hello_dll();
}